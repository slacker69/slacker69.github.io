/*
Copyright (C) 2019  slacker69

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Based on 32 version here: https://blogorama.nerdworks.in/selfdeletingexecutables/
But rewritten for x86_64
x86_64-w64-mingw32-gcc -o selfdel64.exe selfdel64.c
*/
#include <windows.h>
#include <stdio.h>

//From http://bytepointer.com/resources/tebpeb64.h
#include "ntundoc64.h"

typedef PEB64* PPEB;

typedef struct _PROCESS_BASIC_INFORMATION {
    PVOID Reserved1;
    PPEB PebBaseAddress;
    PVOID Reserved2[2];
    ULONG_PTR UniqueProcessId;
    PVOID Reserved3;
} PROCESS_BASIC_INFORMATION;

#define ProcessBasicInformation 0

typedef FARPROC NTQUERYINFORMATIONPROCESS;

typedef struct _LOCALSTORAGE
{
	HANDLE	hParent;
	unsigned char	szFileName[MAX_PATH];
} LOCALSTORAGE;

int main(int arc, char *argv[]){
	STARTUPINFO			    si = { sizeof(si) };
	PROCESS_INFORMATION pi;
	LOCALSTORAGE        local;
  DWORD64 pebAddressIbaOffset;
  DWORD64 pebImageBaseAddress;
  WORD wOffset;
  DWORD64 pebOptHeaderOffset;
  DWORD64 pebOptHeaderOffsetEntryPointOffset;
  DWORD pebOptEntryPoint;
  DWORD64 process_entry;

  /*
   *  Metasploit blockapi-based shellcode 
   *  Win32 DeleteFileA prelude + MessageBoxA
   *  No encoder or badchars specified, outputting raw payload
   *  Payload size: 433 bytes
   *  
   *  Note: shellcodes typically set off Anti-Virus, this one will too
   */

  char shellcode[] = {
    '\xfc', '\x48', '\x83', '\xe4', '\xf0', '\xe8', '\xc8', '\x00', '\x00', '\x00', '\x41', '\x51', '\x41', '\x50', '\x52', '\x51', 
    '\x56', '\x48', '\x31', '\xd2', '\x65', '\x48', '\x8b', '\x52', '\x60', '\x48', '\x8b', '\x52', '\x18', '\x48', '\x8b', '\x52', 
    '\x20', '\x48', '\x8b', '\x72', '\x50', '\x48', '\x0f', '\xb7', '\x4a', '\x4a', '\x4d', '\x31', '\xc9', '\x48', '\x31', '\xc0', 
    '\xac', '\x3c', '\x61', '\x7c', '\x02', '\x2c', '\x20', '\x41', '\xc1', '\xc9', '\x0d', '\x41', '\x01', '\xc1', '\xe2', '\xed', 
    '\x52', '\x41', '\x51', '\x48', '\x8b', '\x52', '\x20', '\x8b', '\x42', '\x3c', '\x48', '\x01', '\xd0', '\x66', '\x81', '\x78', 
    '\x18', '\x0b', '\x02', '\x75', '\x72', '\x8b', '\x80', '\x88', '\x00', '\x00', '\x00', '\x48', '\x85', '\xc0', '\x74', '\x67', 
    '\x48', '\x01', '\xd0', '\x50', '\x8b', '\x48', '\x18', '\x44', '\x8b', '\x40', '\x20', '\x49', '\x01', '\xd0', '\xe3', '\x56', 
    '\x48', '\xff', '\xc9', '\x41', '\x8b', '\x34', '\x88', '\x48', '\x01', '\xd6', '\x4d', '\x31', '\xc9', '\x48', '\x31', '\xc0', 
    '\xac', '\x41', '\xc1', '\xc9', '\x0d', '\x41', '\x01', '\xc1', '\x38', '\xe0', '\x75', '\xf1', '\x4c', '\x03', '\x4c', '\x24', 
    '\x08', '\x45', '\x39', '\xd1', '\x75', '\xd8', '\x58', '\x44', '\x8b', '\x40', '\x24', '\x49', '\x01', '\xd0', '\x66', '\x41', 
    '\x8b', '\x0c', '\x48', '\x44', '\x8b', '\x40', '\x1c', '\x49', '\x01', '\xd0', '\x41', '\x8b', '\x04', '\x88', '\x48', '\x01', 
    '\xd0', '\x41', '\x58', '\x41', '\x58', '\x5e', '\x59', '\x5a', '\x41', '\x58', '\x41', '\x59', '\x41', '\x5a', '\x48', '\x83', 
    '\xec', '\x20', '\x41', '\x52', '\xff', '\xe0', '\x58', '\x41', '\x59', '\x5a', '\x48', '\x8b', '\x12', '\xe9', '\x4f', '\xff', 
    '\xff', '\xff', '\x5d', '\x48', '\x31', '\xc9', '\x48', '\x31', '\xdb', '\xbb', '\x67', '\x68', '\x4a', '\x6b', '\x48', '\xc1', 
    '\xcb', '\x20', '\x48', '\x81', '\xc3', '\x41', '\x73', '\x44', '\x46', '\x48', '\xff', '\xc1', '\x48', '\x8d', '\x44', '\x0d', 
    '\x00', '\x48', '\x8b', '\x00', '\x48', '\x39', '\xd8', '\x75', '\xf0', '\x48', '\x89', '\xce', '\x48', '\x31', '\xd2', '\x52', 
    '\x48', '\x8d', '\x4c', '\x35', '\x08', '\x48', '\x8b', '\x09', '\x41', '\xba', '\x08', '\x87', '\x1d', '\x60', '\xff', '\xd5', 
    '\x48', '\x8d', '\x4c', '\x35', '\x08', '\x48', '\x8b', '\x09', '\x41', '\xba', '\xc6', '\x96', '\x87', '\x52', '\xff', '\xd5', 
    '\x48', '\x8d', '\x4c', '\x35', '\x10', '\x41', '\xba', '\xd7', '\x2e', '\xdd', '\x13', '\xff', '\xd5', '\x48', '\x85', '\xc0', 
    '\x74', '\xee', '\x48', '\x31', '\xc9', '\x51', '\x48', '\x83', '\xe4', '\xf0', '\x48', '\xb9', '\x75', '\x73', '\x65', '\x72', 
    '\x33', '\x32', '\x00', '\x00', '\x51', '\x48', '\x89', '\xe1', '\x41', '\xba', '\x4c', '\x77', '\x26', '\x07', '\xff', '\xd5', 
    '\x4d', '\x31', '\xc9', '\x41', '\xb1', '\x10', '\x48', '\xb9', '\x65', '\x20', '\x54', '\x69', '\x74', '\x6c', '\x65', '\x00', 
    '\x51', '\x48', '\xb9', '\x4d', '\x79', '\x20', '\x41', '\x77', '\x73', '\x6f', '\x6d', '\x51', '\x49', '\x89', '\xe0', '\xb9', 
    '\x21', '\x21', '\x00', '\x00', '\x51', '\x48', '\xb9', '\x4d', '\x65', '\x73', '\x73', '\x61', '\x67', '\x65', '\x21', '\x51', 
    '\x48', '\xb9', '\x4d', '\x79', '\x20', '\x4d', '\x61', '\x69', '\x6e', '\x20', '\x51', '\x48', '\x89', '\xe2', '\x48', '\x31', 
    '\xc9', '\x51', '\x48', '\x83', '\xe4', '\xf0', '\x41', '\xba', '\x45', '\x83', '\x56', '\x07', '\xff', '\xd5', '\x6a', '\x00', 
    '\x59', '\x41', '\xba', '\x4d', '\x81', '\x1b', '\xaa', '\xff', '\xd5', '\x41', '\x73', '\x44', '\x46', '\x67', '\x68', '\x4a', 
    '\x6b'
  };

	if(!CreateProcess(0, "explorer.exe", 0, 0, TRUE, CREATE_SUSPENDED|IDLE_PRIORITY_CLASS, 0, 0, &si, &pi))
	  return 1;
	  
  DuplicateHandle(GetCurrentProcess(), GetCurrentProcess(), pi.hProcess, &local.hParent, 0, FALSE, 0);
  GetModuleFileName(0, local.szFileName, MAX_PATH);

  HMODULE hNtDll = LoadLibrary("NtDll.dll");
  NTQUERYINFORMATIONPROCESS pNtQueryInformationProcess = (NTQUERYINFORMATIONPROCESS)GetProcAddress(hNtDll, "NtQueryInformationProcess");

  PROCESS_BASIC_INFORMATION BasicInfo;
  DWORD dwReturnLength = 0;
  NTSTATUS Status = pNtQueryInformationProcess(pi.hProcess, ProcessBasicInformation, &BasicInfo, sizeof(PROCESS_BASIC_INFORMATION), &dwReturnLength);
  FreeLibrary(hNtDll);

  pebAddressIbaOffset = (DWORD64)(BasicInfo.PebBaseAddress) + 0x10;
  ReadProcessMemory(pi.hProcess, (DWORD64*)(pebAddressIbaOffset), &pebImageBaseAddress, sizeof(pebImageBaseAddress), 0);
  ReadProcessMemory(pi.hProcess, (DWORD64*)(pebImageBaseAddress+0x3c), &wOffset, sizeof(wOffset), 0);
  pebOptHeaderOffset =  pebImageBaseAddress + (DWORD64)wOffset + 0x18;
  pebOptHeaderOffsetEntryPointOffset = pebOptHeaderOffset + 0x10;
  ReadProcessMemory(pi.hProcess, (DWORD64*)(pebOptHeaderOffsetEntryPointOffset), &pebOptEntryPoint, sizeof(pebOptEntryPoint), 0);
  process_entry = pebImageBaseAddress + pebOptEntryPoint;

  VirtualProtectEx( pi.hProcess,
                    (PVOID)process_entry,
                    sizeof(shellcode)+sizeof(local),
                    PAGE_EXECUTE_READWRITE,
                    0);

  WriteProcessMemory( pi.hProcess,
                      (PVOID)process_entry,
                      shellcode,
                      sizeof(shellcode), 0);
  WriteProcessMemory( pi.hProcess,
                      (PVOID)process_entry+sizeof(shellcode),
                      &local,
                      sizeof(local), 0);
  ResumeThread(pi.hThread);
  CloseHandle(pi.hThread);
  CloseHandle(pi.hProcess);
  return 0;
}

